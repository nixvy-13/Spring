<!DOCTYPE html>
<html>
<head>
    <title>To do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>To do List</h1>

        <form action="<?php echo e(route('tasks.store')); ?>" method="POST" class="mb-4">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <input type="text" name="title" class="form-control" placeholder="Nueva tarea">
                <button class="btn btn-primary" type="submit">Añadir</button>
            </div>
        </form>

        <ul class="list-group">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <form action="<?php echo e(route('tasks.toggle', $task)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="checkbox" onChange="this.form.submit()" <?php echo e($task->completed ? 'checked' : ''); ?>>
                            <span class="<?php echo e($task->completed ? 'text-decoration-line-through' : ''); ?>">
                                <?php echo e($task->title); ?>

                            </span>
                        </form>
                    </div>
                    <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</body>
</html><?php /**PATH /home/ivyel/Escritorio/ProyectoLaravel/ORMLaravel/resources/views/tasks/index.blade.php ENDPATH**/ ?>