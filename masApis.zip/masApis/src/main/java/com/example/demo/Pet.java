package com.example.demo;

public record Pet (int id, String type, double price){}
