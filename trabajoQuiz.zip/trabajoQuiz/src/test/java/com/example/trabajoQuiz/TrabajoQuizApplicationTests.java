package com.example.trabajoQuiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
